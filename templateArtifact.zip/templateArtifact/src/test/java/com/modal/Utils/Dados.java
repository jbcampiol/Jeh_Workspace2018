package com.modal.Utils;

public class Dados {
	
	/** Caminho do SETUP dos Browsers **/

	/** - Windows - **/
	// Caminho do DRIVER dos Browsers
	public static String Browser_Chrome_Local = new String("\\Users\\Public\\Selenium\\WebDriver\\Browser\\chromedriver.exe");
	public static String Browser_Chrome_Projeto = new String(".\\driver\\browser\\chromedriver.exe");
	public static String Browser_Firefox_Local = new String("\\Selenium WebDriver\\Browser\\geckodriver.exe");
	public static String Browser_Firefox_Projeto = new String(".\\driver\\browser\\geckodriver.exe");
	public static String Browser_IE_Local = new String("\\Selenium WebDriver\\Browser\\IEDriverServer.exe");
	public static String Browser_IE_Projeto = new String(".\\driver\\browser\\IEDriverServer.exe");
	public static String Browser_Edge_Local = new String("\\Selenium WebDriver\\Browser\\MicrosoftWebDriver.exe");
	public static String Browser_Edge_Projeto = new String(".\\driver\\browser\\MicrosoftWebDriver.exe");
	public static String Browser_Opera_Local = new String("\\Selenium WebDriver\\Browser\\operadriver.exe");
	public static String Browser_Opera_Projeto = new String(".\\driver\\browser\\operadriver.exe");
	//public static String Browser_Safari = new String("C:\\Program Files (x86)\\Browsers\\Safari.exe");
	
	
	/** Sites - Diversos **/
	
	/** - Produção - **/
	public static String Producao_Site_Google = new String("https://www.google.com.br/");
	
	
	/** Sites - SmartLink **/
	
	/** - Produção - **/
	public static String Producao_Site_SmartLink = new String("https://iot.deca.com.br/");
	public static String Producao_JSON = new String("https://paterx-development.firebaseio.com/Balance.json");
	/**
	 * 
	 * **/
		public static String Producao_Usuario_SmartLink = new String("decaiotqa@gmail.com");
		public static String Producao_Senha_SmartLink = new String("asdqweasdqwe");
	/**
	 * 
	 * **/
}
