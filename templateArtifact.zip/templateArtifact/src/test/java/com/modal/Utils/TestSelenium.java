package com.modal.Utils;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TestSelenium {

	 //ATUTestRecorder recorder;
	
	@Before
	public void setUp() throws Exception {
		
		WebUtils browser = new WebUtils(WebUtils.seleniumDriver);
		browser.OpenBrowser("Chrome");
		
		//WebUtils video = new WebUtils(WebUtils.seleniumDriver);
		browser.RecorderStart();
			
	}

	@After
	public void tearDown() throws Exception {
		
		WebUtils browser = new WebUtils(WebUtils.seleniumDriver);
		browser.CloseBrowser();

		//WebUtils video = new WebUtils(WebUtils.seleniumDriver);
		browser.RecorderStop();
		
		
	}

	@Test
	public void test() {
		
		WebUtils browser = new WebUtils(WebUtils.seleniumDriver);
		

		  browser.URL("http://google.com.br/");
		
		
		
	}

}
